package com.evidencia.db;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ConexionDB {

    private static final String URL = "jdbc:mysql://localhost:3306/tienda?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USER = "root";      // Ajusta si tu usuario es otro
    private static final String PASSWORD = "";      // Ajusta si tienes contraseña

    // Carga explícita del driver (útil para errores ClassNotFound)
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("ERROR: Driver JDBC de MySQL no encontrado. Añade mysql-connector-java.jar en Libraries.");
        }
    }

    // Obtener conexión
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // CREATE
    public static boolean insertarCliente(String nombre, String correo) {
        String sql = "INSERT INTO clientes(nombre, correo) VALUES(?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, nombre);
            ps.setString(2, correo);
            int filas = ps.executeUpdate();
            if (filas == 0) {
                System.err.println("Insert falló, filas afectadas = 0");
                return false;
            }
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    System.out.println("Insertado OK. ID generado = " + rs.getInt(1));
                }
            }
            return true;
        } catch (SQLException ex) {
            System.err.println("Error INSERT: " + ex.getMessage());
            return false;
        }
    }

    // READ
    public static List<String> listarClientes() {
        List<String> lista = new ArrayList<>();
        String sql = "SELECT id, nombre, correo FROM clientes";
        try (Connection conn = getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(rs.getInt("id") + " | " + rs.getString("nombre") + " | " + rs.getString("correo"));
            }
        } catch (SQLException ex) {
            System.err.println("Error SELECT: " + ex.getMessage());
        }
        return lista;
    }

    // UPDATE
    public static boolean actualizarCliente(int id, String nuevoNombre) {
        String sql = "UPDATE clientes SET nombre=? WHERE id=?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nuevoNombre);
            ps.setInt(2, id);
            int filas = ps.executeUpdate();
            System.out.println("Filas actualizadas: " + filas);
            return filas > 0;
        } catch (SQLException ex) {
            System.err.println("Error UPDATE: " + ex.getMessage());
            return false;
        }
    }

    // DELETE
    public static boolean eliminarCliente(int id) {
        String sql = "DELETE FROM clientes WHERE id=?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int filas = ps.executeUpdate();
            System.out.println("Filas eliminadas: " + filas);
            return filas > 0;
        } catch (SQLException ex) {
            System.err.println("Error DELETE: " + ex.getMessage());
            return false;
        }
    }

    // Main de prueba (ejecuta Run File sobre esta clase)
    public static void main(String[] args) {
        System.out.println("INICIANDO PRUEBAS BD");
        boolean ins = insertarCliente("David", "david@mail.com");
        System.out.println("Insert OK? " + ins);
        List<String> clientes = listarClientes();
        clientes.forEach(System.out::println);
        // Si existe id 1 lo actualiza y elimina para prueba; ajusta según tu BD.
        if (!clientes.isEmpty()) {
            // extraer un id del primer registro (formato: "id | nombre | correo")
            String primero = clientes.get(0);
            int id = Integer.parseInt(primero.split("\\|")[0].trim());
            actualizarCliente(id, "NombreActualizado");
            eliminarCliente(id);
        }
        System.out.println("PRUEBAS FINALIZADAS");
    }
}

